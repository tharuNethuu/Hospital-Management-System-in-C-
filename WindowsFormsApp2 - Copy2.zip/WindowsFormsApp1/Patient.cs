﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Patient : Form
    {
        public Patient()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""E:\3rd sem\EE 3254 - Programming Project\HMS\WindowsFormsApp2 - Copy\WindowsFormsApp1\HMS.db.mdf"";Integrated Security=True;Connect Timeout=30");

        void populate()
        {
            Con.Open();
            string query = "select * from PatientTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PatientGV.DataSource = ds.Tables[0];
            Con.Close();

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home h= new Home();
            h.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (PatID.Text == "" || PatName.Text == "" || PatAdr.Text == "" || PatPhone.Text == "" || PatAge.Text == "" || MajorDs.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            if (IsPatientIDExists(PatID.Text))
            {
                MessageBox.Show("Patient ID cannot be duplicated");
                return;
            }
            else
            {
                Con.Open();
                string query = "insert into PatientTbl values(" + PatID.Text + ",'" + PatName.Text + "','" + PatAdr.Text + "','" + PatPhone.Text + "',"+ PatAge.Text +",'"+ GenderCb.SelectedItem.ToString() +"','"+BloodCb.SelectedItem.ToString()+"','"+MajorDs.Text+"')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully Added");
                Con.Close();
                populate();
            }
        }
        private bool IsPatientIDExists(string patientID)
        {
            Con.Open();
            string query = "SELECT COUNT(*) FROM PatientTbl WHERE PatID = @PatientID";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.Parameters.AddWithValue("@PatientID", patientID);
            int count = (int)cmd.ExecuteScalar();
            Con.Close();
            return count > 0;
        }

        private void Patient_Load(object sender, EventArgs e)
        {
            populate();
            PatientGV.Columns["PatID"].HeaderText = "Patient ID";
            PatientGV.Columns["PatName"].HeaderText = "Patient Name";
            PatientGV.Columns["PatAddress"].HeaderText = "Patient Address";
            PatientGV.Columns["PatPhone"].HeaderText = "Patient Phone";
            PatientGV.Columns["PatAge"].HeaderText = "Patient Age";
            PatientGV.Columns["PatGender"].HeaderText = "Gender";
            PatientGV.Columns["PatBlood"].HeaderText = "Blood Type";
            PatientGV.Columns["PatDiseases"].HeaderText = "Major Diagnosis";
            PatientGV.EnableHeadersVisualStyles = false;

            PatientGV.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (PatID.Text == "")
                MessageBox.Show("Enter the Patient Id");
            else
            {
                Con.Open();
                string query = "delete from PatientTbl where PatID=" + PatID.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully Deleted");
                Con.Close();
                populate();
            }
        }

        private void PatientGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PatID.Text = PatientGV.SelectedRows[0].Cells[0].Value.ToString();
            PatName.Text = PatientGV.SelectedRows[0].Cells[1].Value.ToString();
            PatAdr.Text = PatientGV.SelectedRows[0].Cells[2].Value.ToString();
            PatPhone.Text = PatientGV.SelectedRows[0].Cells[3].Value.ToString();
            PatAge.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            MajorDs.Text = PatientGV.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "update PatientTbl set PatName='" + PatName.Text + "', PatAddress='" + PatAdr.Text + "', PatPhone='" + PatPhone.Text + "', PatAge=" + PatAge.Text + ", PatGender='" + GenderCb.SelectedItem.ToString() + "', PatBlood='" + BloodCb.SelectedItem.ToString() + "' where PatID=" + PatID.Text + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Patient Successfully Updated");
            Con.Close();
            populate();
        }

    }
}
