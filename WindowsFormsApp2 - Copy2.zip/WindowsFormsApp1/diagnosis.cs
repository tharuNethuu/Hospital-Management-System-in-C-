﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class diagnosis : Form
    {
        public diagnosis()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""E:\3rd sem\EE 3254 - Programming Project\HMS\WindowsFormsApp2 - Copy\WindowsFormsApp1\HMS.db.mdf"";Integrated Security=True;Connect Timeout=30");
        
        void populatecombo()
        {
            string sql = "select * from PatientTbl";
            SqlCommand cmd = new SqlCommand(sql, Con);
            SqlDataReader rdr;
            try
            {
                Con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("PatID", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                PatientIDCb.ValueMember = "PatID";
                PatientIDCb.DataSource = dt;
                Con.Close();
            }
            catch
            {

            }
        }
        string patname;
        void fecthpatientname()
        {
            Con.Open();
            string mysql = "select * from PatientTbl where PatID=" + PatientIDCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(mysql, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                patname = dr["PatName"].ToString();
                PatientTb.Text = patname;
            }
            Con.Close();
        }

        void populate()
        {
            Con.Open();
            string query = "select * from DiagnosisTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DiagnosisGV.DataSource = ds.Tables[0];
            Con.Close();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            HOME2 h = new HOME2();
            h.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DiagID.Text == "" || PatientTb.Text == "" || SympTb.Text == "" || DiagnosisTb.Text == "" || MedicineTb.Text == "" )
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "insert into DiagnosisTbl values(" + DiagID.Text + "," + PatientIDCb.SelectedValue.ToString() + ",'" + PatientTb.Text + "','" + SympTb.Text + "','" + DiagnosisTb.Text + "','" + MedicineTb.Text + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully Added");
                Con.Close();
                populate();
            }
        }

        private void diagnosis_Load(object sender, EventArgs e)
        {
            populatecombo();
            populate();

            DiagnosisGV.Columns["DiagID"].HeaderText = "Diagnosis ID";
            DiagnosisGV.Columns["PatID"].HeaderText = "Patient ID";
            DiagnosisGV.Columns["PatName"].HeaderText = "Patient Name";
            DiagnosisGV.Columns["Symptoms"].HeaderText = "Symptoms";
            DiagnosisGV.Columns["Diagnosis"].HeaderText = "Diagnosis";
            DiagnosisGV.Columns["Medicines"].HeaderText = "Medicine";

            DiagnosisGV.EnableHeadersVisualStyles = false;

            DiagnosisGV.ColumnHeadersDefaultCellStyle.BackColor = Color.Aquamarine;
        }

        private void PatientIDCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fecthpatientname();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (DiagID.Text == "")
                MessageBox.Show("Enter the Diagnosis Id");
            else
            {
                Con.Open();
                string query = "delete from DiagnosisTbl where DiagID=" + DiagID.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully Deleted");
                Con.Close();
                populate();
            }
        }

        private void DiagnosisGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DiagID.Text = DiagnosisGV.SelectedRows[0].Cells[0].Value.ToString();
            PatientIDCb.SelectedValue = DiagnosisGV.SelectedRows[0].Cells[1].Value.ToString();
            PatientTb.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            SympTb.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            DiagnosisTb.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            MedicineTb.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
            PatientNamelbl.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            Diagnosislbl.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            Symptomslbl.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            Medicineslbl.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "update DiagnosisTbl set PatID = " + PatientIDCb.SelectedValue.ToString()  + ", PatName ='" + PatientTb.Text + "', Symptoms='" + SympTb.Text + "',Diagnosis='"+DiagnosisTb.Text+"', Medicines='"+MedicineTb.Text+"' where DiagID=" + DiagID.Text + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Diagnosis Successfully Updated");
            Con.Close();
            populate();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string printedDate = "Printed Date: " + DateTime.Now.ToString("MMMM dd, yyyy HH:mm:ss");

            e.Graphics.DrawString(printedDate, new Font("Franklin Gothic Medium", 14, FontStyle.Regular), Brushes.Black, new Point(50, 50));
            e.Graphics.DrawString("\n" + "\n" + "\n" + "           " + label8.Text, new Font("Franklin Gothic Medium", 25, FontStyle.Bold), Brushes.Red, new Point(230));
            e.Graphics.DrawString("\n\n" + label10.Text + ":  " + PatientNamelbl.Text + "\n" + "\n" + label16.Text + ":         " + Diagnosislbl.Text + "\n" + "\n" + label13.Text + ":       " + Symptomslbl.Text + "\n" + "\n" + label12.Text + ":        " + Medicineslbl.Text, new Font("Franklin Gothic Medium", 20, FontStyle.Regular), Brushes.Black, new Point(130, 150));
            e.Graphics.DrawString("\n\n\n\n" + "                " + label14.Text, new Font("Franklin Gothic Medium", 14, FontStyle.Italic), Brushes.MediumSlateBlue, new Point(230, 380));
            Image image = Image.FromFile(@"C:\Users\USER\OneDrive\Desktop\programming project\BLUE LOGO.png");
            e.Graphics.DrawImage(image, new Rectangle(320, 800, 240, 210));
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void diagsummary_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
